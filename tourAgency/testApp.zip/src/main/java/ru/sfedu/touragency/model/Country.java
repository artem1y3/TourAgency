package ru.sfedu.touragency.model;

public enum Country {
    RUSSIA,
    FRANCE,
    NORWAY
}
