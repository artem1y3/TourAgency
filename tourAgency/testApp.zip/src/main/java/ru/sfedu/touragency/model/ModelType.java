package ru.sfedu.touragency.model;

public enum ModelType {
    SIMPLE_USER,
    PRO_USER,
    ORDER,
    TOUR,
    HOTEL
}
