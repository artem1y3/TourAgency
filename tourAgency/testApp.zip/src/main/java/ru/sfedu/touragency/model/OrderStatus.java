package ru.sfedu.touragency.model;

public enum OrderStatus {
    SENT,
    PAID
}
