package ru.sfedu.touragency.api;

import ru.sfedu.touragency.model.ModelType;

import java.util.List;

public interface IDataProvider {
    void saveOrUpdate(ModelType type, Object obj);
    List<Object> getAll(ModelType type);
    Object getById(ModelType type, long id);
    void delete(ModelType type, long id);
}
