import org.junit.Test;
import ru.sfedu.touragency.Constans;
import ru.sfedu.touragency.utils.ConfigurationUtil;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class DataProviderJdbcTest {
    @Test
    public void connectionTest() throws IOException, ClassNotFoundException, SQLException {
        Class.forName(ConfigurationUtil.getConfigurationEntry(Constans.DRIVER_CLASS));
        Properties props = new Properties();
        props.setProperty("user",  ConfigurationUtil.getConfigurationEntry(Constans.JDBC_URL));
        props.setProperty("password",  ConfigurationUtil.getConfigurationEntry(Constans.JDBC_URL));
        String url = ConfigurationUtil.getConfigurationEntry(Constans.JDBC_URL);
        Connection conn = DriverManager.getConnection(url, props);

        Statement statement = conn.createStatement();
        statement.executeQuery("CREATE TABLE IF NOT EXISTS testtable(a int primary key)");

        PreparedStatement st = conn.prepareStatement("INSERT INTO testtable VALUES (?)");
        st.setInt(1, 521);
        st.executeUpdate();

        statement.close();
        st.close();
        conn.close();
    }
}
