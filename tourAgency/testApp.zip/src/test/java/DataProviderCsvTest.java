import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import org.junit.Test;
import ru.sfedu.touragency.model.Hotel;

import java.io.*;
import java.math.BigDecimal;
import java.util.Arrays;

public class DataProviderCsvTest {
    @Test
    public void save(){
        String path = "/tmp/hotel.csv";
        Hotel hotel = new Hotel();
        hotel.setId(5);
        hotel.setName("Verona");
        hotel.setDescription("The best hotel of my life");
        hotel.setRate(new BigDecimal("4.3"));

        try (Writer w = new FileWriter(path);
             CSVWriter writer = new CSVWriter(w))
        {
            writer.writeNext(new String[]{
                String.valueOf(hotel.getId()),
                hotel.getName(),
                hotel.getDescription(),
                hotel.getRate().toString()
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void readAll(){
        String path = "/tmp/hotel.csv";
        try (Reader r = new FileReader(path);
             CSVReader reader = new CSVReader(r))
        {
            for(String[] entry : reader.readAll()){
                System.out.println(Arrays.toString(entry));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
